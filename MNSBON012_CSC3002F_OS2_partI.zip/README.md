# OS2_partI

unzip folder and use "make" command in terminal 
run the BarrierTest.java program with 2 arguments 
    first being the size of the barrier
    second the number of threads